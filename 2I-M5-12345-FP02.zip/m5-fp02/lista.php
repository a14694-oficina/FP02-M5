<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $item1 = $_POST["item1"];
    $item2 = $_POST["item2"];
    $item3 = $_POST["item3"];
    $item4 = $_POST["item4"];
    $item5 = $_POST["item5"];

    $itens = [$item1, $item2, $item3, $item4, $item5];

    echo "<h2>Lista de Compras</h2>";
    echo "<ul>";
    
    foreach($itens as $item){
    if(!empty($item)){
        echo "<li>$item</li>";
    }
}
    echo "</ul>";
    echo "-------------------------------------------------------------------------------------------";
    echo "<br />";
    ?>

    <!-- ---------------------------------------------------------------------------- -->

    <?php
    $turma = [
        "Ana"  => 16,
        "João" => 17,
        "Mara" => 18,
        "Pedro" => 16,
        "Sofia" => 17
    ];  
    
    $alunos = ["Ana", "João", "Mara", "Pedro", "Sofia"];
    $idades = array(16, 17, 18, 16, 17);

    echo "<h2>Tabela de Alunos e Idades</h2>";
    echo "<br />";

    echo "<table border='1'>";
    foreach($alunos as $a){
        echo "<li>$a</li>";
    }
    foreach($idades as $i){
        echo "<tr><td>$i</td></tr>";
        foreach($alunos as $a){
            echo "<li>$a</li>";
        }
    }
    
    echo "</table>";
    ?>

    <?php
    echo "<br />";
    echo "-------------------------------------------------------------------------------------------";
    ?>

    <!-- ---------------------------------------------------------------------------- -->
    <?php
    ?>
    <h2>Classificação Automática</h2>

</body>
</html>